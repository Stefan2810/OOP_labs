#include "carte.hpp"


Carte::Carte():Autor()
{
    titlu=NULL;
    nr_pagini=0;
}

Carte::Carte(char* n,int v,char* t,int nr):Autor(n,v)
{
    titlu=new char[strlen(t)+1];
    strcpy(titlu,t);

    nr_pagini=nr;
}

Carte::Carte(const Carte& aux):Autor(aux)
{
    titlu=new char[strlen(aux.titlu)+1];
    strcpy(titlu,aux.titlu);

    nr_pagini=aux.nr_pagini;
}

Carte::~Carte()
{
    delete[]titlu;
}

Carte& Carte:: operator=(Carte& obiect)
{
    Autor::operator=(obiect);

    this->titlu=new char[strlen(obiect.titlu)+1];
    strcpy(this->titlu,obiect.titlu);

    this->nr_pagini=obiect.nr_pagini;

    return (*this);
}

istream& operator>>(istream& in,Carte& obj)
{
    in>>(Autor&)obj;
    char buff[50];
    cin>>buff;
    delete[]obj.titlu;
    obj.titlu=new char[strlen(buff)+1];
    strcpy(obj.titlu,buff);
    in>>obj.nr_pagini;
    return in;
}

ostream& operator<<(ostream& out,const Carte& obj)
{
    out<<(Autor &)obj<<"Titlul cartii: "<<obj.titlu<<"\nNumarul de pagini: "<<obj.nr_pagini<<"\n";
    return out;
}

int GetNr_pag(Carte& obj)
{
    return obj.nr_pagini;
}
