#include "autor.hpp"

Autor::Autor()
{
    nume=NULL;
    varsta=0;
}

Autor::Autor(char* n,int v)
{
    nume=new char[strlen(n)+1];
    strcpy(nume,n);

    varsta=v;
}

Autor::Autor(const Autor& obj)
{
    nume=new char[strlen(obj.nume)+1];
    strcpy(nume,obj.nume);

    varsta=obj.varsta;
}

Autor::~Autor()
{
    delete[]nume;
}

Autor& Autor::operator=(Autor& obj)
{
    this->nume=new char[strlen(obj.nume)+1];
    strcpy(this->nume,obj.nume);

    this->varsta=obj.varsta;

    return (*this);
}

istream& operator>>(istream& in,Autor& obj)
{
    char buff[50];
    cin>>buff;
    delete[]obj.nume;
    obj.nume=new char[strlen(buff)+1];
    strcpy(obj.nume,buff);
    in>>obj.varsta;
    return in;
}

ostream& operator<<(ostream& out,const Autor& obj)
{
    out<<"Nume autor: "<<obj.nume<<"\nVarsta autor: "<<obj.varsta<<"\n";
    return out;
}
