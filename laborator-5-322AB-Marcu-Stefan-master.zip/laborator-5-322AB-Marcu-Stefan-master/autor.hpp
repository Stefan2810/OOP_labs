#include <iostream>
#include <cstring>
#include <math.h>
#include <iomanip>

using namespace std;

class Autor{
protected:
    char* nume;
    int varsta;
public:
    Autor();
    Autor(char *n,int v);
    Autor(const Autor &obj);
    ~Autor();
    Autor& operator=(Autor& obj);
    friend istream& operator>>(istream& in,Autor& obj);
    friend ostream& operator<<(ostream& out,const Autor& obj);
};
