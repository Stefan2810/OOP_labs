#include "carte.hpp"

int main()
{
    Carte *v;
    int i,j,n=2;
    v=new Carte[4];
    for(i=0;i<n;i++)
        cin>>v[i];
    cout<<endl<<endl;
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
        {
            if(GetNr_pag(v[i]) > GetNr_pag(v[j]))
            {
                Carte aux;
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
        }
    for(i=0;i<n;i++)
        cout<<v[i]<<endl;
    cout<<endl<<endl;
    for(i=0;i<n;i++)
        if(GetNr_pag(v[i])>100)
            cout<<v[i];
    delete[]v;
    return 0;
}
