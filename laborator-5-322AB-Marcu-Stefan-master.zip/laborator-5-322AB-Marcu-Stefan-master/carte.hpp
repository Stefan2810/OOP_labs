#include "autor.hpp"

class Carte:public Autor{
    char* titlu;
    int nr_pagini;
public:
    Carte();
    Carte(char* n,int v,char* t,int nr);
    Carte(const Carte& aux);
    ~Carte();
    Carte& operator=(Carte& obiect);
    friend istream& operator>>(istream& in,Carte& obj);
    friend ostream& operator<<(ostream& out,const Carte& obj);
    friend int GetNr_pag(Carte& obj);
};
