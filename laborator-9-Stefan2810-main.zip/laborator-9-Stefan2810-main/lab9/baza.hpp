#ifndef baza_hpp
#define baza_hpp

#include <iostream>

using namespace std;

class Baza{

public:
    virtual int getVarsta()=0;
    virtual void afisare()=0;
    virtual int Ou()=0;
    virtual ~Baza(){};

};

#endif
