#ifndef gaina_hpp
#define gaina_hpp

#include "pui.hpp"

class Gaina:public Pui
{
    int nr_oua;
public:
    Gaina();
    Gaina(int v,int g,int nr);
    void afisare();
    int Ou();
};

#endif
