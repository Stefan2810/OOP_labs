#ifndef vaca_hpp
#define vaca_hpp

#include "baza.hpp"

class Vaca:public Baza{
    int varsta;
    int greutate;
public:
    Vaca();
    Vaca(int v,int g);
    void afisare();
    int getVarsta();
    int Ou();
};

#endif
