#include "pui.hpp"

Pui::Pui()
{
    varsta=0;
    greutate=0;
}

Pui::Pui(int v,int g)
{
    varsta=v;
    greutate=g;
}

void Pui::afisare()
{
    cout<<"Pt pui : "<<"Greutatea este: "<<greutate<<" Varsta este: "<<varsta<<endl;
}

int Pui::getVarsta()
{
    return this->varsta;
}

int Pui::getGreutate()
{
    return this->greutate;
}

int Pui::Ou(){
    return 0;
}
