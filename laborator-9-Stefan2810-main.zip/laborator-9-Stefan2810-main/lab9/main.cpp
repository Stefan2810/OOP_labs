#include "porc.hpp"
#include "cal.hpp"
#include "vaca.hpp"
#include "gaina.hpp"

int main()
{
    Baza **v;
    v=new Baza*[5];
    v[0]=new Pui(1,1);
    v[1]=new Porc(3,100);
    v[2]=new Cal(2,400);
    v[3]=new Vaca(6,500);
    v[4]=new Gaina(2,2,12);


    for(int i=0;i<4;i++)
        for(int j=i+1;j<5;j++)
            if( v[i]->getVarsta() > v[j]->getVarsta() )
                //swap(v[i],v[j]);
                {
                    Baza *aux;
                    aux=v[i];
                    v[i]=v[j];
                    v[j]=aux;
                }

    for(int i=0;i<5;i++)
        v[i]->afisare();

    cout<<endl<<endl;

    for(int i=0 ; i<5 ; i++)
        if(v[i]->Ou() == 1)
            v[i]->afisare();

    for(int i=0;i<5;i++)
        delete v[i];

    delete[]v;
    return 0;
}
