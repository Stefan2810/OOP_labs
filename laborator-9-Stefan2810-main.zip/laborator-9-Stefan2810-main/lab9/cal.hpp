#ifndef cal_hpp
#define cal_hpp

#include "baza.hpp"

class Cal:public Baza{
    int varsta;
    int greutate;
public:
    Cal();
    Cal(int v,int g);
    void afisare();
    int getVarsta();
    int Ou();
};

#endif
