#include "gaina.hpp"

Gaina::Gaina():Pui()
{
    nr_oua=0;
}

Gaina::Gaina(int v,int g,int nr):Pui(v,g)
{
    nr_oua=nr;
}

void Gaina::afisare()
{
    cout<<"Gaina are nr de oua= "<<nr_oua<<" greutatea: "<<this->getGreutate()<<" varsta: "<<this->getVarsta()<<endl;
}

int Gaina::Ou(){
    return 1;
}
