#ifndef porc_hpp
#define porc_hpp

#include "baza.hpp"

class Porc:public Baza{
    int varsta;
    int greutate;
public:
    Porc();
    Porc(int v,int g);
    void afisare();
    int getVarsta();
    int Ou();
};

#endif
