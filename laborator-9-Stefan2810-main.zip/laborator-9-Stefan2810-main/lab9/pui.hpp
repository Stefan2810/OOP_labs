#ifndef pui_hpp
#define pui_hpp

#include "baza.hpp"

class Pui:public Baza{
    int varsta;
    int greutate;
public:
    Pui();
    Pui(int v,int g);
    void afisare();
    int getVarsta();
    int Ou();
    int getGreutate();
};

#endif
