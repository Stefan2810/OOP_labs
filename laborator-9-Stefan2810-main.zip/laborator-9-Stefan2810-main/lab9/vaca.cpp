#include "vaca.hpp"

Vaca::Vaca()
{
    varsta=0;
    greutate=0;
}

Vaca::Vaca(int v,int g)
{
    varsta=v;
    greutate=g;
}

void Vaca::afisare()
{
    cout<<"Pt vaca: "<<"Greutatea este: "<<greutate<<" Varsta este: "<<varsta<<endl;
}

int Vaca::getVarsta()
{
    return this->varsta;
}

int Vaca::Ou(){
    return 0;
}

