#include "porc.hpp"

Porc::Porc()
{
    varsta=0;
    greutate=0;
}

Porc::Porc(int v,int g)
{
    varsta=v;
    greutate=g;
}

void Porc::afisare()
{
    cout<<"Pt porc "<<"Greutatea este: "<<greutate<<" Varsta este: "<<varsta<<endl;
}

int Porc::getVarsta()
{
    return this->varsta;
}

int Porc::Ou(){
    return 0;
}
