#include "cal.hpp"

Cal::Cal()
{
    varsta=0;
    greutate=0;
}

Cal::Cal(int v,int g)
{
    varsta=v;
    greutate=g;
}

void Cal::afisare()
{
    cout<<"Pt Cal:"<<"Greutatea este: "<<greutate<<" Varsta este: "<<varsta<<endl;
}

int Cal::getVarsta()
{
    return this->varsta;
}

int Cal::Ou(){
    return 0;
}
