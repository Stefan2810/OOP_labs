#include "Nr_complex.hpp"
#include "Fractie.hpp"

template<class x>

class Vector{
    int dim;
    x *buf;
public:
    Vector();
    Vector(int d,x *v);
    Vector(Vector& obj);
    void afisare();
    Vector sortare();
};
