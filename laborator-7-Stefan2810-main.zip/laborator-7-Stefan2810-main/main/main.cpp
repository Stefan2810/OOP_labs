#include "Vector.hpp"

int main()
{
    int v[3]={1,3,2};
    Vector<int>a(3,v);
    //a.afisare();

    double aux[3]={8.11 , 5.04 , 4.03};
    Vector<double>b(3,aux);
    //b.afisare();

    Nr_complex vec[3]={Nr_complex(2,3),Nr_complex(4,4),Nr_complex(2,0)};
    Vector<Nr_complex>c(3,vec);
    //c.afisare();

    Fractie sir[3]={Fractie(10,1),Fractie(20,4),Fractie(15,5)};
    Vector<Fractie>d(3,sir);
    //d.afisare();

    a.sortare();
    a.afisare();

    b.sortare();
    b.afisare();

    c.sortare();
    c.afisare();

    d.sortare();
    d.afisare();

    return 0;
}
