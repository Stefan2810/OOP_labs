#include "Nr_complex.hpp"

Nr_complex::Nr_complex()
{
    r=0;
    i=0;
}

Nr_complex::Nr_complex(int a,int b)
{
    r=a;
    i=b;
}

void Nr_complex::afisare()
{
    cout<<"Partea reala este: "<<r<<"\nPartea imaginara este: "<<i<<"\n";
}


ostream& operator<<(ostream& out,const Nr_complex& obj)
{
    out<<"Partea reala este: "<<obj.r<<"\nPartea imaginara este: "<<obj.i<<"\n";
    return out;
}

double Nr_complex::Modul() const
{
    return sqrt(this->r * this->r + this->i * this->i);
}

bool Nr_complex::operator<(const Nr_complex& obj)
{
    if( this->Modul() < obj.Modul() )
            return true;
    return false;
}
