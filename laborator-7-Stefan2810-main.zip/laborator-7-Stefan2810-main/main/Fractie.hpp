#include <iostream>

using namespace std;

class Fractie{
    double numarator;
    double numitor;
public:
    Fractie();
    Fractie(double a,double b);
    void afisare();
    friend ostream& operator<<(ostream& out,const Fractie& obj);
    bool operator<(const Fractie& obj);
};
