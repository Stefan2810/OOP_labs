#include <iostream>
#include <math.h>

using namespace std;

class Nr_complex{
    int r;
    int i;
public:
    Nr_complex();
    Nr_complex(int a,int b);
    void afisare();
    friend ostream& operator<<(ostream& out,const Nr_complex& obj);
    double Modul() const;
    bool operator<(const Nr_complex& obj);
};
