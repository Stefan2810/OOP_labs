#include "Vector.hpp"

template<class x>

Vector<x>::Vector()
{
    dim=0;
    buf=NULL;
}

template<class x>
Vector<x>::Vector(int d,x *v)
{
    dim=d;
    buf=new x[dim];
    for(int i=0;i<dim;i++)
        buf[i]=v[i];
}

template<class x>
Vector<x>::Vector(Vector& obj)
{
    dim=obj.dim;
    buf=new x[dim];
    for(int i=0;i<dim;i++)
        buf[i]=obj.buf[i];
}

template<class x>
void Vector<x>::afisare()
{
    cout<<"Dimensiunea este: "<<dim<<"\nVectorul este: \n";
    for(int i=0;i<dim;i++)
        cout<<buf[i]<<' ';
    cout<<endl;
}

template <class x>
Vector<x> Vector<x>::sortare()
{
     for(int i=0;i<2;i++)
        for(int j=i+1;j<3;j++)
    {
        if(this->buf[i]<this->buf[j])
        {
            x aux;
            aux=this->buf[i];
            this->buf[i]=this->buf[j];
            this->buf[j]=aux;
        }

    }
    return *this;
}

void Test()
{
    int v[3]={1,2,3};
    Vector<int>a,a2(3,v);
    a.afisare();

    double aux[2]={8.11 , 5.04};
    Vector<double>b,b2(2,aux);
    b.afisare();

    Nr_complex vec[3]={Nr_complex(2,3),Nr_complex(4,4),Nr_complex(6,0)};
    Vector<Nr_complex>c,c2(2,vec);
    c.afisare();

    Fractie sir[2]={Fractie(10,1),Fractie(20,4)};
    Vector<Fractie>d,d2(2,sir);
    d.afisare();

    a.sortare();
    b.sortare();
    c.sortare();
    d.sortare();
}
