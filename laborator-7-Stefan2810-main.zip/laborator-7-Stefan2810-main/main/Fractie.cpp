#include "Fractie.hpp"

Fractie::Fractie()
{
    numarator=0;
    numitor=0;
}

Fractie::Fractie(double a,double b)
{
    numarator=a;
    numitor=b;
}

void Fractie::afisare()
{
    cout<<"Numaratorul este: "<<numarator<<"\nNumitorul este: "<<numitor<<"\n";
}

ostream& operator<<(ostream& out,const Fractie& obj)
{
    out<<"Numaratorul este: "<<obj.numarator<<"\nNumitorul este: "<<obj.numitor<<"\n";
    return out;
}

bool Fractie::operator<(const Fractie& obj)
{
    if( this->numarator/this->numitor < obj.numarator/obj.numitor)
        return true;
    return false;
}

