#include "NrComplex.hpp"

NrComplex:: NrComplex(int r,int i)
{
    this->r=r;
    this->i=i;
}

NrComplex :: NrComplex(const NrComplex& obj)
{
    r=obj.r;
    i=obj.i;
}

NrComplex& NrComplex:: operator=(const NrComplex& obj)
{
    this->r=obj.r;
    this->i=obj.i;
    return *this;
}

double NrComplex::getModul()
{
    return sqrt(r*r+i*i);
}

NrComplex NrComplex::getConj()const
{
    NrComplex a;
    a.r=r;
    a.i=-i;
    return a;
}

void NrComplex::setData(int a,int b)
{
    r=a;
    i=b;
}

float NrComplex::getR()
{
    return (float)r;
}

float NrComplex::getI()
{
    return (float)i;
}

NrComplex operator-(const NrComplex& obj)
{
    NrComplex a;
    a.r=-obj.r;
    a.i=-obj.i;
    return a;
}

NrComplex operator +(const NrComplex& a,const NrComplex& b)
{
    NrComplex obj;
    obj.r=a.r+b.r;
    obj.i=a.i+b.i;
    return obj;
}

NrComplex operator -(const NrComplex& a,const NrComplex& b)
{
    NrComplex obj;
    obj.r=a.r-b.r;
    obj.i=a.i-b.i;
    return obj;
}

NrComplex operator *(const NrComplex& a,const NrComplex& b)
{
    NrComplex obj;
    obj.r=a.r*b.r-a.i*b.i;
    obj.i=a.r*b.i+a.i*b.r;
    return obj;
}
NrComplex operator /(const NrComplex& a,const NrComplex& b)
{
    NrComplex obj,x;
    x=b.getConj();
    obj.r=(a.r*x.r-a.i*x.i)/(b.r*b.r+b.r*b.i-b.r*b.i-b.i*b.i);
    obj.i=(a.r*b.i+a.i*b.r)/(b.r*b.r+b.r*b.i-b.r*b.i-b.i*b.i);
    return obj;
}

NrComplex& NrComplex::operator +=(const NrComplex& obj)
{
    *this=(*this)+obj;
    return *this;
}

NrComplex& NrComplex::operator -=(const NrComplex& obj)
{
    *this=(*this)-obj;
    return *this;
}

NrComplex& NrComplex::operator *=(const NrComplex& obj)
{
    *this=(*this)*obj;
    return *this;
}

NrComplex& NrComplex::operator /=(const NrComplex& obj)
{
    *this=(*this)/obj;
    return *this;
}

bool NrComplex::operator ==(const NrComplex& obj)
{
    if(this->r==obj.r && this->i==obj.i)
        return true;
    return false;
}

bool NrComplex::operator !=(const NrComplex& obj)
{
    if(this->r==obj.r && this->i==obj.i)
        return false;
    return true;
}

bool NrComplex::operator <(const NrComplex& obj)
{
    if(this->i==0 && obj.i==0)
    {
        if( this->r < obj.r )
            return true;
        return false;
    }
    return false;
}

bool NrComplex::operator >(const NrComplex& obj)
{
    if(this->i==0 && obj.i==0)
    {
        if( this->r > obj.r )
            return true;
        return false;
    }
    return false;
}

bool NrComplex::operator <=(const NrComplex& obj)
{
    if(this->i==0 && obj.i==0)
    {
        if( this->r <= obj.r )
            return true;
        return false;
    }
    return false;
}

bool NrComplex::operator >=(const NrComplex& obj)
{
    if(this->i==0 && obj.i==0)
    {
        if( this->r >= obj.r )
            return true;
        return false;
    }
    return false;
}

void NrComplex::afisare()
{
    cout<<r<<" "<<i<<endl;
}
