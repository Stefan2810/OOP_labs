#include "NrComplex.hpp"

int main()
{
    NrComplex a(0,3);
    NrComplex b(a);
    NrComplex c(1,1);
    cout<<"a: ";
    a.afisare();
    cout<<"b: ";
    b.afisare();
    cout<<"c: ";
    c.afisare();

    NrComplex x;
    cout<<"x: ";
    x.afisare();
    x=a;
    cout<<"x=a ==> ";
    x.afisare();

    if( b==a )
        cout<<"Merge operatorul ==";
    else
        cout<<"Nu merge";

    cout<<endl;

    if(c!=a)
        cout<<"Operatorul != merge";
    else
        cout<<"Nu merge";
    cout<<endl;

    cout<<"Modulul lui a este: "<<a.getModul()<<endl;

    cout<<"Partea reala a lui a este: "<<a.getR()<<endl<<"Parte imaginara a lui a este: "<<a.getI()<<endl;

    cout<<"a+b= ";
    (a+b).afisare();

    cout<<"c-b= ";
    (c-b).afisare();

    cout<<"a*b= ";
    (a*b).afisare();

    cout<<"a/b= ";
    (a/b).afisare();

    cout<<"b+=a ==> ";
    b+=a;
    b.afisare();

    b=a;
    cout<<"b-=c ==> ";
    b-=c;
    b.afisare();

    b=a;
    cout<<"b*=a ==> ";
    b*=a;
    b.afisare();

    b=a;
    cout<<"b/=a ==> ";
    b/=a;
    b.afisare();

    NrComplex d(11,0);
    cout<<"d: ";
    d.afisare();
    NrComplex e(12,0);
    cout<<"e: ";
    e.afisare();
    NrComplex f(1,0);
    cout<<"f: ";
    f.afisare();
    NrComplex g(1,0);
    cout<<"g: ";
    g.afisare();
    if( d.getI()==0 && e.getI()==0 && f.getI()==0 && g.getI()==0)
    {
        if( d<e )
            cout<<"Merge operatorul <";
        else
            cout<<"Nu merge operatorul";

        cout<<endl;

        if( e>d )
            cout<<"Merge operatorul >";
        else
            cout<<"Nu merge operatorul";

        cout<<endl;

        if( f<=g )
            cout<<"Merge operatorul <=";
        else
            cout<<"Nu merge operatorul";

        cout<<endl;

        if( f>=g )
            cout<<"Merge operatorul <=";
        else
            cout<<"Nu merge operatorul";

        cout<<endl;
    }
    else
        cout<<"Numerele nu pot fii comparate";
    cout<<endl;

    cout<<"Verificam daca merge functia - apeland functia -(c) "<<endl;
    (-c).afisare();

    return 0;
}
