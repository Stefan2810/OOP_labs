#include <iostream>
#include <cstring>
#include <math.h>

using namespace std;

class NrComplex
{
    int r; //partea reala
    int i; //partea imaginara
public:
    NrComplex(int r=0,int i=0);
    NrComplex(const NrComplex& );
    NrComplex& operator=(const NrComplex& );
    double getModul();
    NrComplex getConj()const;
    void setData(int ,int );
    float getR();
    float getI();
    friend NrComplex operator +(const NrComplex& ,const NrComplex& );
    friend NrComplex operator -(const NrComplex& ,const NrComplex& );
    friend NrComplex operator *(const NrComplex& ,const NrComplex& );
    friend NrComplex operator /(const NrComplex& ,const NrComplex& );
    friend NrComplex operator -(const NrComplex& ); ///trebuie ca r+j --> -r-j
    NrComplex& operator +=(const NrComplex& );
    NrComplex& operator -=(const NrComplex& );
    NrComplex& operator *=(const NrComplex& );
    NrComplex& operator /=(const NrComplex& );
    bool operator ==(const NrComplex& );
    bool operator !=(const NrComplex& );
    bool operator <(const NrComplex& );
    bool operator >(const NrComplex& );
    bool operator <=(const NrComplex& );
    bool operator >=(const NrComplex& );
    void afisare();
};
