#include "magazin.hpp"

Magazin::Magazin()
{
}

Magazin::Magazin(vector <Produs> cump,vector <Produs> vand):cumparare(cump),vanzare(vand)
{

}

void Magazin::cauta_in_cumparare(char* nume,int stoc,int price)
{
    int i;
    for( i=0 ; i<this->cumparare.size() ; i++ )
    {
        if(strcmp(this->cumparare[i].getNume(),nume)==0 )
        {
            cumparare[i].cresteStoc(stoc);
            break;
        }
    }
    if( i==this->cumparare.size() )
    this->cumparare.push_back(Produs(nume,price,stoc));
}

void Magazin::cauta_in_vanzare(char* nume,int stoc,int price)
{
    int i;
    for( i=0 ; i<this->vanzare.size() ; i++ )
    {
        if(strcmp(this->vanzare[i].getNume(),nume)==0 )
        {
            vanzare[i].cresteStoc(stoc);
            break;
        }
    }
    if( i==this->vanzare.size() )
    this->vanzare.push_back(Produs(nume,price,stoc));
}

void Magazin::afisare_mag()
{
    cout<<"Produsele cumparate de magazin sunt: "<<endl;
    for(int i=0;i<this->cumparare.size(); i++)
        (this->cumparare[i]).afisare();
    cout<<"Produsele vandute de magazin sunt: "<<endl;
    for(int i=0 ; i<this->vanzare.size() ; i++ )
        (this->vanzare[i]).afisare();
}

int Magazin::Nr_cioc()
{
    int i,nr=0;
    for( i=0 ; i<this->cumparare.size() ; i++ )
    {
        if(strcmp(this->cumparare[i].getNume(),"ciocolata")==0 )
        {
            nr=this->cumparare[i].getStoc();
        }
    }
    return nr;
}

int Magazin::Vanzare_totala()
{
    int i,suma=0;
    for( i=0 ; i<this->vanzare.size() ; i++)
        suma+=(this->vanzare[i].getPret() * this->vanzare[i].getStoc());
    return suma;
}

int Magazin::Valoare_stoc()
{
    int i,suma=0;
    for( i=0 ; i<this->cumparare.size() ; i++)
        suma+=(this->cumparare[i].getPret() * this->cumparare[i].getStoc());
    return suma;
}
/*
void Magazin::afisare_fisiere()
{
    ofstream fout("Cumparare.txt");
    fout<<"Produsele cumparate de magazin sunt: "<<endl;
    for(int i=0;i<this->cumparare.size(); i++)
        (this->cumparare[i]).afisare_fiser()
    fout.close()
*/
