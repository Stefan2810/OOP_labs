#include "magazin.hpp"


int main()
{
    vector<Produs> vec1;
    vector<Produs> vec2;

    vec1.push_back(Produs("mere",7,21));
    vec1.push_back(Produs("pere",11,10));
    vec1.push_back(Produs("gutui",15,8));

    vec2.push_back(Produs("afine",20,31));
    vec2.push_back(Produs("mere",8,20));

    vec1[0].afisare();

    Magazin la_2_pasi(vec1,vec2);

    la_2_pasi.afisare_mag();

    cout<<"Numarul de ciocolate pe stoc este: "<<la_2_pasi.Nr_cioc()<<endl;

    cout<<"Banii in casa sunt: "<<la_2_pasi.Vanzare_totala()<<endl;

    cout<<"Valoarea stocului este: "<<la_2_pasi.Valoare_stoc()<<endl;


    return 0;
}
