#ifndef produs_hpp
#define produs_hpp

#include <iostream>
#include <cstring>

using namespace std;

class Produs{
    char *denumire;
    int pret;
    int numar_produse;
public:
    Produs();
    Produs(char* nume,int pr,int nr_prod);
    Produs(const Produs& obj);
    ~Produs();
    Produs cresteStoc(int nr);
    char* getNume();
    int getStoc();
    int getPret();
    void afisare();
    void afisare_fiser_cumpare();
    void afisare_fiser_vanzare();
    Produs& operator=(const Produs& obj);
};

#endif
