#ifndef magazin_hpp
#define magazin_hpp

#include "produs.hpp"
#include <vector>

class Magazin:public Produs{
vector <Produs> cumparare;
vector <Produs> vanzare;
public:
    Magazin();
    Magazin(vector <Produs> cump,vector <Produs> vand);
    void cauta_in_cumparare(char* nume,int stoc,int price);
    void cauta_in_vanzare(char* nume,int stoc,int price);
    void afisare_mag();
    int Nr_cioc();
    int Vanzare_totala();
    int Valoare_stoc();
    void afisare_fisiere();
};

#endif // magazin_hpp
