#include "produs.hpp"

Produs::Produs()
{
    denumire=NULL;
    pret=0;
    numar_produse=0;
}

Produs::Produs(char* nume,int pr,int nr_prod)
{
    pret=pr;
    numar_produse=nr_prod;
    denumire=new char[strlen(nume)+1];
    strcpy(denumire,nume);
    //cout<<denumire<<endl;
}

Produs::Produs(const Produs& obj)
{
    pret=obj.pret;
    numar_produse=obj.numar_produse;
    denumire=new char[strlen(obj.denumire)+1];
    strcpy(denumire,obj.denumire);
}

Produs::~Produs()
{
    delete[]denumire;
}

Produs Produs::cresteStoc(int nr)
{
    this->numar_produse += nr;
    return (*this);
}

char* Produs::getNume()
{
    return this->denumire;
}

void Produs::afisare()
{
    cout<<"Produsul "<<this->denumire<<" are un stoc de: "<<this->numar_produse<<" la pretul de: "<<this->pret<<endl;
}
///Nu merge okay operatorul =
/*
Produs& Produs::operator=(const Produs& obj)
{
    this->pret=obj.pret;
    this->numar_produse=obj.numar_produse;
    cout<<"egal"<<endl;
    delete[](this->denumire);
    cout<<"egal"<<endl;
    this->denumire=new char[strlen(obj.denumire)+1];
    cout<<"egal"<<endl;
    strcpy(this->denumire,obj.denumire);
    return *this;
}*/

int Produs::getStoc()
{
    return this->numar_produse;
}

int Produs::getPret()
{
    return this->pret;
}
/*
void afisare_fiser_cumparare()
{
    ofstream fout("Cumparare.out");
    fout<<"Produsul "<<this->denumire<<" are un stoc de: "<<this->numar_produse<<" la pretul de: "<<this->pret<<endl;
    fout.close();
}

void afisare_fiser_vanzare()
{
    ofstream fout("Vanzare.out");
    fout<<"Produsul "<<this->denumire<<" are un stoc de: "<<this->numar_produse<<" la pretul de: "<<this->pret<<endl;
    fout.close();
}*/
