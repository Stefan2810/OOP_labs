#include "gradina.hpp"

Gradina::Gradina():Teren()
{
    suprafata=0;
    pret=0;
}

Gradina::Gradina(char* nume,int pret_teren,int s,int p):Teren(nume,pret_teren){
    suprafata=s;
    pret=p;
}

int Gradina::getPret_total(){
    return Teren::getPret_total()+this->pret;
}

void Gradina::afisare()
{
    Teren::afisare();
    cout<<"Suprafata gradinii este: "<<suprafata<<endl<<"Pretul gradinii este: "<<pret<<endl;
}

int Gradina::getSup(){
    return this->suprafata;
}

int Gradina::getPret(){
    return this->pret;
}
/*
Gradina Gradina::copy_pret(int aux){
    pret=aux;
    return *this;
}

Gradina Gradina::copy_sup(int aux){
    suprafata=aux;
    return *this;
}
*/
