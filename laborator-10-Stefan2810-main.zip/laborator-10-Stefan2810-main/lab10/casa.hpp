#ifndef casa_hpp
#define casa_hpp

#include "teren.hpp"

class Casa:public virtual Teren{
    int suprafata;
    int pret; ///pret total= pret casa +  pret teren
public:
    Casa();
    Casa(char* nume,int pret_teren,int s,int p);
    int getPret_total();
    void afisare();
    int getSup();
    int getPret();
    ///Casa copy_sup(int aux);
    ///Casa copy_pret1(int aux);
};

#endif
