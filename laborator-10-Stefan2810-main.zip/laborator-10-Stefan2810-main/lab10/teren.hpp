#ifndef teren_hpp
#define teren_hpp

#include <iostream>
#include <cstring>

using namespace std;

class Teren{
    char* proprietar;
    int pret;
public:
    Teren();
    Teren(char* pr,int p);
    virtual char* getProprietar();
    virtual int getPret();
    virtual void afisare();
    virtual int getPret_total();
    ///virtual Teren copy_pret(int aux);
    virtual ~Teren();
};

#endif
