#ifndef casa_cu_gradina_hpp
#define casa_cu_gradina_hpp

#include "casa.hpp"
#include "gradina.hpp"

class Casa_cu_gradina:public Casa,public Gradina{
    char adresa[30];
    ///pret total=pret casa + pret gradina + pret teren
public:
    Casa_cu_gradina();
    Casa_cu_gradina(char* nume,int pret_teren,int suprafata_casa,int pret_casa,int suprafata_gradina,int pret_gradina,char adres[]);
    int getPret_total();
    void afisare();
    ///Casa_cu_gradina operator +(Casa_cu_gradina& aux);
    int getPret(){return 0;};
};

#endif // casa_cu_gradina_hpp
