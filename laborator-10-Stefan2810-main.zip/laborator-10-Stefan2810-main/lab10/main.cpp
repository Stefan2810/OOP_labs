#include "casa_cu_gradina.hpp"

int main()
{
    Teren **v;
    v=new Teren*[4];

    char *aux1;
    aux1=new char[6];
    strcpy(aux1,"Ionel");
    v[0]=new Casa(aux1,1000,300,1500);

    char *aux2;
    aux2=new char[7];
    strcpy(aux2,"George");
    v[1]=new Gradina(aux2,200,100,350);

    char *aux3;
    aux3=new char[6];
    strcpy(aux3,"Tudor");
    v[2]=new Teren(aux3,250);

    char *aux4;
    aux4=new char[5];
    strcpy(aux4,"Radu");
    char aux5[]="Bdv.Carol I";
    v[3]=new Casa_cu_gradina(aux4,1500,1000,5000,250,700,aux5);

    for ( int i=0 ; i<3 ; i++)
        for ( int j=i+1 ; j<4 ; j++)
            if( v[i]->getPret_total() > v[j]->getPret_total() )
                {
                    Teren* aux;
                    aux=v[i];
                    v[i]=v[j];
                    v[j]=aux;
                }

    for(int i=0 ; i<4 ; i++)
        v[i]->afisare();

    delete[]aux1;
    delete[]aux2;
    delete[]aux3;
    delete[]aux4;
    for(int i=0; i<4; i++)
        delete v[i];
    delete []v;
    return 0;
}
