#include "teren.hpp"

Teren::Teren(){
    proprietar=NULL;
    pret=0;
}

Teren::Teren(char* pr,int p)
{
    proprietar=new char[strlen(pr)+1];
    strcpy(proprietar,pr);
    pret=p;
}

Teren::~Teren(){
    delete[]proprietar;
}

int Teren::getPret_total(){
    return this->pret;
}

void Teren::afisare(){
    cout<<"Numele proprietarului este: "<<proprietar<<endl<<"Pretul terenului este: "<<pret<<endl;
}

char* Teren::getProprietar(){
    return this->proprietar;
}

int Teren::getPret(){
    return this->pret;
}

/*
Teren Teren::copy_pret(int aux){
    pret=aux;
    return *this;
}
*/
