#include "casa.hpp"

Casa::Casa():Teren()
{
    suprafata=0;
    pret=0;
}

Casa::Casa(char* nume,int pret_teren,int s,int p):Teren(nume,pret_teren){
    suprafata=s;
    pret=p;
}

int Casa::getPret_total(){
    return Teren::getPret_total()+this->pret;
}

void Casa::afisare()
{
    Teren::afisare();
    cout<<"Suprafata casei este: "<<suprafata<<endl<<"Pretul casei este: "<<pret<<endl;
}

int Casa::getSup()
{
    return this->suprafata;
}

int Casa::getPret()
{
    return this->pret;
}
/*
Casa Casa::copy_pret(int aux){
    this->pret=aux;
    return *this;
}

Casa Casa::copy_sup(int aux){
    this->suprafata=aux;
    return *this;
}
*/
