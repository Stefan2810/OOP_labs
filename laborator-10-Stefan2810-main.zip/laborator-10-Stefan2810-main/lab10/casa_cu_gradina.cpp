#include "casa_cu_gradina.hpp"

Casa_cu_gradina::Casa_cu_gradina():Gradina(),Casa(),Teren(){
    strcpy(adresa,NULL);
}

Casa_cu_gradina::Casa_cu_gradina(char* nume,int pret_teren,int suprafata_casa,int pret_casa,int suprafata_gradina,int pret_gradina,char adres[]):Gradina(nume,pret_teren,suprafata_gradina,pret_gradina),
Casa(nume,pret_teren,suprafata_casa,pret_casa),Teren(nume,pret_teren){
    strcpy(adresa,adres);
}

int Casa_cu_gradina::getPret_total()
{
    return Gradina::getPret_total()+Casa::getPret_total()-Teren::getPret_total();
}

void Casa_cu_gradina::afisare()
{
    Casa::afisare();
    cout<<"Suprafata gradinii este: "<<Gradina::getSup()<<endl<<"Pretul gradinii este: "<<Gradina::getPret()<<endl;
    cout<<"Adresa este: "<<adresa<<endl;
}

Casa_cu_gradina Casa_cu_gradina::operator  +(Casa_cu_gradina& aux){

    Casa_cu_gradina obj();
    //strcpy(obj.proprietar,this->proprietar);
    /*obj.Teren::copy_pret( Teren::getPret() - aux.Teren::getPret());
    obj.Casa::copy_pret( Casa::getPret() - aux.Casa::getPret());
    obj.Gradina::copy_pret( Gradina::getPret() - aux.Gradina::getPret());
    */
    return obj;
}

