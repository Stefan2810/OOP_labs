#ifndef gradina_hpp
#define gradina_hpp

#include "teren.hpp"

class Gradina:public virtual Teren{
    int suprafata;
    int pret; ///pret total= pret gradina + pret teren
public:
    Gradina();
    Gradina(char* nume,int pret_teren,int s,int p);
    int getPret_total();
    void afisare();
    int getSup();
    int getPret();
    ///Gradina copy_sup();
    ///Gradina copy_pret();
};
#endif // gradina_hpp
