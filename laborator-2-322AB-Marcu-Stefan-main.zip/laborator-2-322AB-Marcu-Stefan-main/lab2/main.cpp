#include "Produs.hpp"

int main()
{
    Produs *v;
    v = new Produs[3];

    v[0].modif("Aa", "a1", "01", 10);
    v[1].modif("Bb", "b1", "02", 100);
    v[2].modif("Cc", "c1", "03", 1);

    for (int i = 0; i < 3; i++)
        v[i].afisare();

    cout << endl;

    int i, j = 0, maxim = v[0].getPret();
    for (i = 1; i < 3; i++)
        if (v[i].getPret() > maxim)
        {
            maxim = v[i].getPret();
            j = i;
        }

    cout << "Produsul cu cel mai mare pret este: ";
    v[j].afisare();

    cout << endl;

    for (i = 0; i < 2; i++)
        for (j = i + 1; j < 3; j++)
            if (v[i].getPret() > v[j].getPret())
            {
                Produs aux;
                aux.modif(v[i]);
                v[i].modif(v[j]);
                v[j].modif(aux);
            }
    for (i = 0; i < 3; i++)
        v[i].afisare();

    delete[] v;

    return 0;
}
