    #include "Produs.hpp"

    Produs::~Produs(){
        delete []nume;
        delete []producator;
    }

    void Produs::afisare(){
        cout<<nume<<" "<<producator<<" "<<cod<<" "<<pret<<endl;
    }

    Produs::Produs(const char *n,const char *p,const char c[],int b)
    {
        if(nume!=NULL)
            delete[]nume;
        nume=new char[strlen(n)+1];
        strcpy(nume,n);
        delete[]producator;
        producator=new char[strlen(p)+1];
        strcpy(producator,p);
        strcpy(cod,c);
        pret=b;
    }

    Produs::Produs()
    {
        nume=NULL;
        producator=NULL;
        strcpy(cod,"");
        pret=0;
    }

    void Produs :: modif(const char *n,const char *p,const char c[],int b)
    {
        delete[]nume;
        nume=new char[strlen(n)+1];
        strcpy(nume,n);
        delete[]producator;
        producator=new char[strlen(p)+1];
        strcpy(producator,p);
        strcpy(cod,c);
        pret=b;
    }

    void Produs :: modif(const Produs&obj)
    {
        delete[]nume;
        nume=new char[strlen(obj.nume)+1];
        strcpy(nume,obj.nume);
        delete[]producator;
        producator=new char[strlen(obj.producator)+1];
        strcpy(producator,obj.producator);
        strcpy(cod,obj.cod);
        pret=obj.pret;
    }

    int Produs :: getPret()const
    {
        return pret;
    }

    char* Produs::getNume()const
    {
        return nume;
    }
