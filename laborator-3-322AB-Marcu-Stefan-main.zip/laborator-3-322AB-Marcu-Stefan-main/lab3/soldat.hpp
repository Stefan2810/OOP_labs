#include <iostream>
#include <cstring>

using namespace std;

class Soldat{
    char* unitate;
    char* nume;
    char cod[6];
    int salariu;

public:
    Soldat();
    Soldat(char* ,char* ,char [],int);
    Soldat(const Soldat&);
    ~Soldat();
    void afisare()const;
    void modif(char* ,char* ,char[],int);
    char* getUnitate()const;
    friend int getSalariu(const Soldat&);
    Soldat& operator=(const Soldat&);
};

