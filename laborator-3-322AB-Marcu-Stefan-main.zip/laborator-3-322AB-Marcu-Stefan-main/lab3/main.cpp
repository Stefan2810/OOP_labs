#include "soldat.hpp"

using namespace std;

int main()
{
    Soldat a();
    Soldat b("a","b","c",20);
    Soldat c(b);
    b.afisare();
    c.afisare();

    cout<<endl;

    Soldat* v;
    v=new Soldat[3];
    v[0].modif("A11","PP","01",200);
    v[1].modif("D12","CC","02",1200);
    v[2].modif("B17","AA","03",1200);

    for(int i=0; i<2 ; i++)
        for(int j=i+1; j<3; j++)
            if(strcmp(v[i].getUnitate(),v[j].getUnitate())>0)
            {
                Soldat aux;
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
    for(int i=0; i<3; i++)
        v[i].afisare();

    cout<<endl;

    int maxim=getSalariu(v[0]);

    for(int i=1; i<3; i++)
        if(getSalariu(v[i])>maxim)
            maxim=getSalariu(v[i]);

    for(int i=0; i<3; i++)
        if(getSalariu(v[i])==maxim)
            v[i].afisare();

    delete[]v;

    return 0;
}
