#include "soldat.hpp"

Soldat::Soldat()
{
    unitate=NULL;
    nume=NULL;
    strcpy(cod,"");
    salariu=0;
}

Soldat::Soldat(char* u,char* n,char c[],int s)
{
    unitate=new char[strlen(u)+1];
    strcpy(unitate,u);

    nume=new char[strlen(n)+1];
    strcpy(nume,n);

    strcpy(cod,c);

    salariu=s;
}

Soldat::Soldat(const Soldat&a)
{
    unitate=new char[strlen(a.unitate)+1];
    strcpy(unitate,a.unitate);

    nume=new char[strlen(a.nume)+1];
    strcpy(nume,a.nume);

    strcpy(cod,a.cod);

    salariu=a.salariu;
}

Soldat::~Soldat()
{
    delete[]unitate;
    delete[]nume;
}

void Soldat::afisare()const
{
    cout<<unitate<<" "<<nume<<" "<<cod<<" "<<salariu;
    cout<<endl;
}

void Soldat::modif(char* u,char* n,char c[],int s)
{
    delete[]unitate;
    unitate=new char[strlen(u)+1];
    strcpy(unitate,u);

    delete[]nume;
    nume=new char[strlen(n)+1];
    strcpy(nume,n);

    strcpy(cod,c);

    salariu=s;
}

char* Soldat::getUnitate()const
{
    return unitate;
}

int getSalariu(const Soldat& a)
{
    return a.salariu;
}

Soldat& Soldat::operator=(const Soldat& a)
{
    delete[]this->unitate;
    this->unitate=new char[strlen(a.unitate)+1];
    strcpy(this->unitate,a.unitate);

    delete[]this->nume;
    this->nume=new char[strlen(a.nume)+1];
    strcpy(this->nume,a.nume);

    strcpy(this->cod,a.cod);

    this->salariu=a.salariu;

    return *this;
}
