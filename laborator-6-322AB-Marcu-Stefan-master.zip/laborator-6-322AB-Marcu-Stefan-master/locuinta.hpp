#include <iostream>
#include <cstring>

using namespace std;

class Locuinta{
protected:
    char* adresa;
    int valoare;
public:
    Locuinta();
    Locuinta(char* a,int v);
    Locuinta(const Locuinta& obj);
    ~Locuinta();
    Locuinta& operator=(const Locuinta& obj);
};
