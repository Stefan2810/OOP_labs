#include "oras.hpp"

namespace cerinta2{
    Locuitor* v;
    Oras x;
}


int main()
{
    cerinta2::v=new Locuitor[3];

    int* v1;
    v1=new int[3];
    v1[0]=100;
    v1[1]=2;
    v1[3]=3;

    int* v2;
    v2=new int[1];
    v2[0]=10;

    int* v3;
    v3=new int[2];
    v3[0]=12;
    v3[1]=14;

    cerinta2::v[0]=Locuitor(v1,3,"Bdv Manole",2300,"Ion");
    cerinta2::v[1]=Locuitor(v2,1,"Bdv Maniu",5500,"Dan");
    cerinta2::v[2]=Locuitor(v3,2,"Bdv Carol",1000,"Mircea");
    cerinta2::x=Oras(cerinta2::v,3,"Marcel");

    Sortare(cerinta2::x);

    cerinta2::x.afisare();

    cout<<endl;

    cerinta2::x=Schimba_primar("Lucian",cerinta2::x);

    cerinta2::x.afisare();

    ///adaugare nou locuitor in x

    Locuitor* vec;
    vec=new Locuitor[4];
    for( int k=0 ; k<3 ; k++)
        vec[k]=cerinta2::v[k];

    delete[]cerinta2::v;

    int* v4;
    v4=new int[1];
    v4[0]=120;

    vec[3]=Locuitor(v4,1,"Bdv Decebal",10000,"Dragos");
    cerinta2::x=Oras(vec,4,"Marcel");

    cerinta2::x.afisare();

    delete[]vec;


    return 0;
}
