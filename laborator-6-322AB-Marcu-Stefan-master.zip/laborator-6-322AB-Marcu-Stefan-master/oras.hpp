#include "locuitor.hpp"

class Oras{
    Locuitor* locuitori;
    int nr_locuitori;
    char* primar;
public:
    Oras();
    Oras(Locuitor* l,int nr_l,char* p);
    Oras(const Oras& obj);
    ~Oras();
    Oras& operator=(const Oras& obj);
    friend Oras Scimba_primar(char* nume,Oras& obj);
    void afisare();
    friend Oras Sortare(Oras& obj);
};
