#include "locuinta.hpp"

Locuinta::Locuinta()
{
    adresa=NULL;
    valoare=0;
}

Locuinta::Locuinta(char* a,int v)
{
    delete[]adresa;
    adresa=new char[strlen(a)+1];
    strcpy(adresa,a);

    valoare=v;
}

Locuinta::Locuinta(const Locuinta& obj)
{
    delete[]adresa;
    adresa=new char[strlen(obj.adresa)+1];
    strcpy(adresa,obj.adresa);

    valoare=obj.valoare;
}

Locuinta::~Locuinta(){
    delete[]adresa;
}

Locuinta& Locuinta:: operator=(const Locuinta& obj)
{
    delete[]this->adresa;
    this->adresa=new char[strlen(obj.adresa)+1];
    strcpy(this->adresa,obj.adresa);

    this->valoare=obj.valoare;

    return (*this);
}

