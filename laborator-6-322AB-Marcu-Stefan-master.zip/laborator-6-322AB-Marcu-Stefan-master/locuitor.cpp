#include "locuitor.hpp"

Locuitor::Locuitor():Impozit(),Locuinta()
{
    nume=NULL;
}

Locuitor::Locuitor(int* t,int nr_t,char* a,int v,char* n):Impozit(t,nr_t),Locuinta(a,v){

    nume=new char[strlen(n)+1];
    strcpy(nume,n);
}

Locuitor::Locuitor(const Locuitor& obj):Impozit(obj),Locuinta(obj){

    nume=new char[strlen(obj.nume)+1];
    strcpy(nume,obj.nume);
}

Locuitor::~Locuitor(){
    delete[]nume;
}

Locuitor& Locuitor:: operator=(const Locuitor& obj)
{
    Impozit::operator=(obj);
    Locuinta::operator=(obj);

    delete[]this->nume;

    this->nume=new char[strlen(obj.nume)+1];
    strcpy(this->nume,obj.nume);

    return(*this);

}

void Locuitor::Afisare(Locuitor& obj)
{
    cout<<obj.nume;
}
