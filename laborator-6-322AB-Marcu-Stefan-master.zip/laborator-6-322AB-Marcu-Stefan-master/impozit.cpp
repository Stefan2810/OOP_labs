#include "impozit.hpp"

Impozit::Impozit()
{
    taxe=NULL;
    nr_taxe=0;
}

Impozit::Impozit(int* t,int nr)
{
    taxe=new int[nr];
    for(int i=0;i<nr;i++)
        taxe[i]=t[i];
    nr_taxe=nr;
}

Impozit::Impozit(const Impozit& obj)
{
    taxe=obj.taxe;
    nr_taxe=obj.nr_taxe;
}

Impozit::~Impozit()
{
    delete[]taxe;
}

Impozit& Impozit:: operator=(const Impozit& obj)
{
    delete[]this->taxe;
    this->taxe=new int[obj.nr_taxe];

    for(int i=0; i<obj.nr_taxe ; i++)
        this->taxe[i]=obj.taxe[i];

    this->nr_taxe=obj.nr_taxe;

    return (*this);
}

int Suma(Impozit& obj)
{
    int suma=0;
    for( int i=0; i<obj.nr_taxe ; i++ )
        suma= suma+obj.taxe[i];
    return suma;
}


