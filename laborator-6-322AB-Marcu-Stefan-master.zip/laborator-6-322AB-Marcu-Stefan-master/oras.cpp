#include "oras.hpp"

namespace cerinta3{
    Locuitor aux;
}

Oras::Oras()
{
    locuitori=NULL;
    nr_locuitori=0;
    primar=NULL;
}

Oras::Oras(Locuitor* l,int nr_l,char* p){

    locuitori=new Locuitor[nr_l];
    for(int i=0; i< nr_l ; i++)
        locuitori[i]=l[i];
    nr_locuitori=nr_l;
    primar=new char[strlen(p)+1];
    strcpy(primar,p);
}

Oras::Oras(const Oras& obj){

    locuitori=new Locuitor[obj.nr_locuitori];
    for(int i=0; i<obj.nr_locuitori  ; i++)
        locuitori[i]=obj.locuitori[i];
    nr_locuitori=obj.nr_locuitori;
    primar=new char[strlen(obj.primar)+1];
    strcpy(primar,obj.primar);
}

Oras::~Oras()
{
    delete[]locuitori;
    delete[]primar;
}

Oras& Oras:: operator=(const Oras& obj)
{
    delete[]this->locuitori;
    this->locuitori=new Locuitor[obj.nr_locuitori];
    for(int i=0;i<obj.nr_locuitori;i++)
        this->locuitori[i]=obj.locuitori[i];

    this->nr_locuitori=obj.nr_locuitori;

    delete[]this->primar;
    this->primar=new char[strlen(obj.primar)+1];
    strcpy(this->primar,obj.primar);

    return(*this);
}

Oras Schimba_primar(char* nume,Oras& obj)
{
    delete[]obj.primar;
    obj.primar=new char[strlen(nume)+1];
    strcpy(obj.primar,nume);
    return *obj;
}

Oras::void afisare()
{
    for(int i=0; i<this->nr_locuitori ; i++)
       {
            cout<<"Numele locuitorului "<<i<<"este :";
            this->locuitori[i].Afisare();

        }
    cout<<"Numele primarului este: "<<this->primar<<endl;
}

Oras Oras::Sortare(Oras& obj)
{
     for( int i=0 ; i<2 ; i++)
        for( int j=i+1 ; j<3 ; j++)
            if( Suma(cerinta2::obj.v[i])> Suma(cerinta2::pbj.v[j]))
            {
                cerinta3::aux=cerinta2::obj.v[i];
                cerinta2::obj.v[i]=cerinta2::obj.v[j];
                cerinta2::obj.v[j]=cerinta3::aux;
            }
    return obj;
}
