#include <iostream>
#include <cstring>

using namespace std;

class Impozit{
protected:
    int* taxe;
    int nr_taxe;
public:
    Impozit();
    Impozit(int* t,int nr);
    Impozit(const Impozit& obj);
    ~Impozit();
    Impozit& operator=(const Impozit& obj);
    friend int Suma(Impozit& obj);
};
