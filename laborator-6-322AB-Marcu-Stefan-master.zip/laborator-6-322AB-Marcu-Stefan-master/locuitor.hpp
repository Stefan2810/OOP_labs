#include "impozit.hpp"
#include "locuinta.hpp"

class Locuitor:public Impozit,public Locuinta{
    char* nume;
public:
    Locuitor();
    Locuitor(int* t,int nr_t,char* a,int v,char* n);
    Locuitor(const Locuitor& obj);
    ~Locuitor();
    Locuitor& operator=(const Locuitor& obj);
    void Afisare(Locuitor& obj);
};
